# Azure Monitor - Extras ( Grafana Datasource plugin for Azure )

### Azure Cost Analysis

![image](https://user-images.githubusercontent.com/153843/82420435-9d5b1800-9a77-11ea-818e-7b57b0f6353c.png)

### Azure Resource Graph

![image](https://user-images.githubusercontent.com/153843/82420772-178b9c80-9a78-11ea-8294-2d0500aa3592.png)

### Azure Service Health

![image](https://user-images.githubusercontent.com/153843/83039982-abd89f00-a036-11ea-98ed-d7fd5dd69141.png)

### Azure Application Insights

Work in progress

### Azure Log Analytics

Work in progress
